# Lynx Editor

Exécutable de l'éditeur, compilé avec le moteur (et non plus dans le jeu).

```
LynxEditor.exe                      -> navigateur de projets
LynxEditor.exe "C:/chemin/MonJeu"   -> ouvre ce projet directement
```

## Projet de jeu

```
MonJeu/
  assets/     <- assets du jeu (world.xml, save_file.txt, input.json, cur/, ...)
  build/      <- la DLL du jeu (ex : Blocky.dll), ou build/<config>/
```

La DLL du jeu est trouvée automatiquement : c'est celle de `build/` qui exporte
`FactoryRegisterClasses` (macro `LYNX_LINK_MODULE`). S'il y en a plusieurs, le
navigateur propose une liste (par défaut la plus récemment compilée).

À l'ouverture, le dossier de travail devient la racine du projet : `assets/`,
`settings.cfg`, `editor_camera.txt`, `editor_windows.txt`, `imgui.ini` sont ceux
du projet. Seule la liste des projets récents (`editor_recent_projects.txt`) est
à côté de l'exécutable de l'éditeur.

Barre d'outils > bouton du projet > *Open another project...* : ferme l'éditeur
(avec la confirmation de sauvegarde habituelle) et relance le navigateur.

## Compiler le jeu pendant que l'éditeur tourne

L'éditeur charge une **copie** de la DLL du jeu (dans `%TEMP%\LynxEditor\`),
jamais `build/<jeu>.dll` elle-même : le fichier n'est pas verrouillé et le jeu
peut être recompilé à tout moment.

- Bouton **Compile** de la barre d'outils : lance `Build.bat` du projet (ou
  `cmake --build build` s'il n'y en a pas) en arrière-plan. La sortie s'affiche
  dans la fenêtre *Build* (erreurs en rouge, bouton *Cancel*). Si la compilation
  réussit, le jeu est rechargé.
- Compilation en dehors de l'éditeur (`Build.bat`, CLion...) : l'éditeur voit
  que `build/<jeu>.dll` a changé et recharge le jeu.
- Pendant *Play*, le rechargement attend *Stop*.
- Options dans *Settings* : « Reload the game after Compile » et « Reload the
  game when its DLL is rebuilt ».
- Si la nouvelle DLL ne se charge pas, l'éditeur revient à la précédente.

`cmake` et MinGW doivent être dans le `PATH` de l'éditeur pour que *Compile*
fonctionne (ce qui est le cas si `Build.bat` marche dans un terminal).

## Compilation automatique à l'ouverture

Avant de charger la DLL du jeu, l'éditeur vérifie qu'elle est à jour. Il compile
le jeu (`Build.bat`, sinon CMake) dans une petite fenêtre qui affiche la sortie
du build :

- **DLL absente** (jeu jamais compilé) : compilation obligatoire.
- **DLL plus ancienne que `lynx.dll`** (moteur recompilé depuis) : compilation
  obligatoire. Cette DLL n'est **jamais** chargée telle quelle, elle ferait planter
  l'éditeur.
- **Sources plus récentes que la DLL** (`src/`, `include/`, `CMakeLists.txt`...) :
  compilation. Si elle échoue, « Open with the previous build » ouvre quand même
  le projet avec l'ancienne DLL.

Si le build échoue : « Retry » après correction, « Other project... » ou « Quit ».
Si l'éditeur plante malgré tout, une boîte de dialogue indique le module en
cause (DLL du jeu ou moteur) au lieu de fermer sans rien dire.

## Commandes (Python / IA)

Fenêtre *Windows > Commands (Python / AI)* : scripts Python du projet
(`<projet>/commands/*.py`), console de commandes, référence de toutes les
commandes, et configuration MCP pour brancher un modèle d'IA. L'éditeur écoute
sur `127.0.0.1` (port 7420 ou suivant) ; la connexion est décrite dans
`<projet>/.lynx/editor.json`. Détails : `python/README.md` (à la racine du moteur).

Code : `editor/commands/` (registre, serveur, runner Python, fenêtre) et
`editor/EditorCommands.inl` (les commandes elles-mêmes).

## Input Settings

Fenêtre *Input Settings* (bouton des fenêtres de la barre d'outils) : édite
`input.json` à la racine du projet, comme les Input Settings d'Unreal.

- **Action Mappings** (`lynx::InputAction`) et **Axis Mappings**
  (`lynx::InputAxis1D`, avec un *scale* par touche).
- Une touche se choisit dans la liste (flèche, avec recherche), ou en cliquant
  sur son bouton puis en appuyant sur la touche voulue : clavier, bouton de
  souris, molette (axes), bouton / stick / gâchette de manette. Échap annule.
- Chaque modification est sauvegardée et rechargée tout de suite : le jeu
  utilise les nouvelles touches sans redémarrer.

Format : les touches clavier sont écrites avec leur nom (`KEY_SPACE`, `KEY_W`,
`KEY_LEFT_SHIFT`...) ; les anciens codes numériques (`"32"`) restent acceptés.
Les noms correspondent à la position sur un clavier QWERTY (codes GLFW), mais
l'éditeur affiche la lettre de ton clavier (`KEY_Q` s'affiche « A » en AZERTY).

## Types de voxels

Décrits dans `assets/voxels.json` (format : `src/core/Voxels.h`), chargés par
l'éditeur et le runtime avant le niveau. Le jeu les lit avec `lynx::voxels`
(`GetFlags`, `GetFlagMask("ROCK")`, `IsIndestructible`, `GetFlagsBelow`...).
*Reload Game* relit aussi `voxels.json`.

## Ce que la DLL du jeu fournit

Fonctions exportées **optionnelles**, décrites dans `core/GameModuleAPI.h` :

| Fonction | Rôle |
|---|---|
| `LynxGame_SetupScene(scene)` | avant le niveau (et après chaque *Reload Game*) : enregistre les événements de voxels |
| `LynxGame_OnGameStart()` / `LynxGame_OnGameEnd()` | début / fin de partie : runtime, *Play* / *Stop* de l'éditeur |
| `LynxGame_OnLevelLoaded(camera)` | niveau (re)créé : démarrage, *Reload Game*, *Stop* |
| `LynxGame_UpdateGameplayCamera(camera, dt)` | caméra de jeu, chaque frame |
| `LynxGame_SetCollisionDebugEnabled(enabled)` | overlay de collisions (F4) |

Une fonction absente est simplement ignorée. Exemple complet : `src/Module.cpp`
du projet Blocky.

## Projets de jeu séparés

Un projet de jeu (ex : Blocky) est un dossier indépendant, n'importe où sur
l'ordinateur, avec son propre `CMakeLists.txt` :

```cmake
find_package(Lynx CONFIG)          # trouvé via le registre CMake
add_library(MonJeu SHARED ...)
target_link_libraries(MonJeu PRIVATE Lynx::Lynx Lynx::HRL)
```

Configurer le moteur génère `LynxConfig.cmake` dans son dossier de build et
l'enregistre dans le registre de paquets CMake de l'utilisateur
(`HKEY_CURRENT_USER\Software\Kitware\CMake\Packages\Lynx`). Pour forcer un
build précis du moteur : `-DLynx_DIR=<dossier de build du moteur>`.
Le jeu doit être compilé avec le même compilateur que le moteur (vérifié).

## Runtime

`LynxRuntime.exe` (`src/runtime`) joue un projet sans l'éditeur :

```
LynxRuntime.exe                     -> projet = dossier de travail
LynxRuntime.exe "C:/chemin/MonJeu"  -> projet = ce dossier
```

La DLL du jeu est cherchée à côté de l'exe (jeu distribué), puis dans
`build/` du projet.

`src/host/` contient le code commun aux deux exécutables (gamepad, projets) :
il n'est ni dans `lynx.dll` ni visible par le jeu.

## Compilation

`src/editor/` ne doit **pas** être compilé dans `lynx.dll` : c'est un exécutable
à part. Il a besoin de :

- `EditorMain.cpp`, `ProjectBrowser.cpp`, `InputSettingsEditor.cpp`, `GameBuild.cpp`, `../host/GameProject.cpp`
- ImGui (branche docking) + backends GLFW / OpenGL3, ImGuiColorTextEdit (`TextEditor.cpp`)
- les mêmes includes et bibliothèques que l'ancienne cible du jeu avec éditeur
  (lynx, hrl, glfw, opengl32), `third-party/stb`

Aucune bibliothèque Windows supplémentaire (le dialogue de dossier charge
`ole32.dll` à l'exécution).

La DLL du jeu doit être compilée avec la même version du moteur que l'éditeur :
elle utilise le `lynx.dll` déjà chargé par l'éditeur.

Police de l'éditeur : `normal-font.ttf` à côté de `LynxEditor.exe` si présent,
sinon celle du projet (`assets/normal-font.ttf`), sinon celle d'ImGui.
