#pragma once

#include <cstdint>

// Max. 32 flags
#define GAME_VOXEL_ROCK (1u << 5)
#define GAME_VOXEL_SAND (1u << 6)

struct VoxelData
{
	uint32_t flags;
	float color[4];
};

inline const VoxelData voxelData[4] = {
	{
		HRL_VOXEL_COLLISION_LEFT |
		HRL_VOXEL_COLLISION_RIGHT |
		HRL_VOXEL_COLLISION_TOP |
		HRL_VOXEL_COLLISION_BOTTOM |
		GAME_VOXEL_ROCK,
		{ 0.20f, 0.75f, 0.30f, 1.f }
	},

	{
		HRL_VOXEL_COLLISION_LEFT |
		HRL_VOXEL_COLLISION_RIGHT |
		HRL_VOXEL_COLLISION_TOP |
		HRL_VOXEL_COLLISION_BOTTOM |
		GAME_VOXEL_SAND,
		{ 0.75f, 0.45f, 0.15f, 1.f }
	},

	{
		HRL_VOXEL_COLLISION_LEFT |
		HRL_VOXEL_COLLISION_RIGHT |
		HRL_VOXEL_COLLISION_TOP |
		HRL_VOXEL_COLLISION_BOTTOM |
		GAME_VOXEL_ROCK,
		{ 0.25f, 0.45f, 0.90f, 1.f }
	},

	{
		HRL_VOXEL_COLLISION_LEFT |
		HRL_VOXEL_COLLISION_RIGHT |
		HRL_VOXEL_COLLISION_TOP |
		HRL_VOXEL_COLLISION_BOTTOM |
		GAME_VOXEL_ROCK,
		{ 2.f, 0.f, 0.f, 1.f }
	}
};