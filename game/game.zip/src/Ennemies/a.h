#pragma once

#include "Ennemy.h"

class A : public Ennemy {
public:
	void Init() override;

private:
	lynx::blend_space bs_default{};
	lynx::animation idle_{sprite, "ennemy/Idle.png", 4};
	lynx::animation walk_{sprite, "ennemy/Walk.png", 6};
};