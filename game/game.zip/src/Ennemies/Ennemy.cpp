#include "Ennemy.h"

Ennemy::Ennemy()
{
	HPROPERTY(life, lynx::Exposed);
}

void Ennemy::Init()
{
	Pawn::Init();
}
