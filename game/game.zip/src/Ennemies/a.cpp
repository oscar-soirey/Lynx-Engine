#include "a.h"

void A::Init()
{
	relative_sprite_transform_.scale.x = 7.f;
	relative_sprite_transform_.scale.y = 7.f;
	relative_sprite_transform_.location.x = 1.f;
	relative_sprite_transform_.location.y = 2.f;

	Ennemy::Init();

	bs_default.add(
				0.f,
				idle_
		);

	bs_default.add(
			1.f,
			walk_
	);

	bs_default.add(
			-1.f,
			walk_
	);
}
